**<span style="color:#56adda">0.0.8</span>**
- Fix ffprobe blindly stopping on "error", now it's slightly smarter

**<span style="color:#56adda">0.0.7</span>**
- Fix vp9 blocking processing, add debug log.

**<span style="color:#56adda">0.0.5</span>**
- Add additional parameters for better quality

**<span style="color:#56adda">0.0.4</span>**
- undo accidental line removal

**<span style="color:#56adda">0.0.3</span>**
- add 10-bit as an option

**<span style="color:#56adda">0.0.2</span>**
- fix crf argument

**<span style="color:#56adda">0.0.1</span>**
- Initial version
