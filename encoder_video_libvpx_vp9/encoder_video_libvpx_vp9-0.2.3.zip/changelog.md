**<span style="color:#56adda">0.2.3</span>**
- Fix ffprobe blindly stopping on "error", now it's slightly smarter

**<span style="color:#56adda">0.2.1</span>**
- Add more robust way of detecting the crop.
- Fix where duration is being fetched.

**<span style="color:#56adda">0.2.0</span>**
- Add a second way to get duration if the original one fails.

**<span style="color:#56adda">0.2.0</span>**
- Add auto-crop for black bars

**<span style="color:#56adda">0.1.1</span>**
- Fix 2-pass encoding option to actually work

**<span style="color:#56adda">0.1.0</span>**
- Add new options for encoding
- Fix issue when there is an image as a video stream
- Change default settings

**<span style="color:#56adda">0.0.5</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.4</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.3</span>**
- Update Plugin for Unmanic v1 PluginHandler compatibility
- Update icon

**<span style="color:#56adda">0.0.2</span>**
- Tidy up plugin code.
- Fix incorrect logger name.

**<span style="color:#56adda">0.0.1</span>**
- Initial version
