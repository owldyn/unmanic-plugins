# Ignore files older than given time
Shamelessly ripped from the recently modified plugin and changed one line to make it work.

plugin for [Unmanic](https://github.com/Unmanic)
