**<span style="color:#56adda">0.0.2</span>**
- Fix the debug log to not be confusing.

**<span style="color:#56adda">0.0.1</span>**
- Initial version. Shamelessly ripped from the recently modified plugin and changed one line.
